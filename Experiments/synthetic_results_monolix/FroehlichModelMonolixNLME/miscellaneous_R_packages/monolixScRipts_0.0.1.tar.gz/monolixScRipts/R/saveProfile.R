#' Saving profiles
#' @export
saveProfile <- function(saveDir, profileResult) {
    utils::write.csv(
        profileResult,
        paste0(saveDir, "profiles.csv"),
        row.names = FALSE
    )
    return(NULL)
}

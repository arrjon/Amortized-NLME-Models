#' Check whether chi2 threshold has been reached
#' @param minRatio Is a number slightly smaller than the likelihood ratio given by the Chi2 distributions 95%-quantile and the likelihood ratio test. The likelihood ratio shoud be larger or equal to exponential of half of the 95% quantile of the chi-square distribution (see pyPESTO calculation of confidence interval)
#' @export
checkLikelihoodRatioThreshold <- function(
    ratio,
    minRatio = 0.145
) {
    if ((ratio) > minRatio) {
        finishProfile <- 0
    } else {
        finishProfile <- 1
    }
    return(finishProfile)
}

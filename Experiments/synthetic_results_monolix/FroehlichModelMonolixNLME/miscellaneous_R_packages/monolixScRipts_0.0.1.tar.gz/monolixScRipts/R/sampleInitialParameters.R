#' Sample initial parameter values for multistart optimization
#' @export
sampleInitialParameters <- function(ratePars, bounds = NULL) {
    newPars <- sapply(seq_len(nrow(ratePars)), function(k) {
        parameterId <- ratePars$name[k]
        val <- ratePars$initialValue[k]
        if (is.null(bounds)) {
            if (val >= 0) {
                valmin <- val / 2
                valmax <- val * 2
            } else {
                valmin <- val * 2
                valmax <- val / 2
            }
        } else {
            # print("Sampling from specified parameter bounds.")
            newBounds <- bounds[bounds$id == parameterId, ]
            valmin <- newBounds$lowerBound
            valmax <- newBounds$upperBound
            distribution <- newBounds$distribution
            # print(paste("Sampling between: (", valmin, "and", valmax, ")"))
        }
        if (distribution == "uniform") {
            stats::runif(
                n = 1,
                min = valmin,
                max = valmax
            )
        } else if (distribution == "normal") {
           stats::rnorm(n = 1, mean = valmin, sd = valmax)
        # Without a specified distribution or anything unknown it should just be uniform
        } else {
            warning(paste0("No distribution for initial parameter values of `", parameterId, "` specified. Can be either 'normal' or 'uniform'. Using uniform distribution."))
            stats::runif(
                n = 1,
                min = valmin,
                max = valmax
            )
        }
        }
    )
    return(newPars)
}
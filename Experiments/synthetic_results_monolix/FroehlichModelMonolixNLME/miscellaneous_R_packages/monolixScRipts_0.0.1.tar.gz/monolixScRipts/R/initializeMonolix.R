#' Initialize monolix
#' @export
initializeMonolix <- function() {
    lixoftConnectors::initializeLixoftConnectors(software = "monolix")
}
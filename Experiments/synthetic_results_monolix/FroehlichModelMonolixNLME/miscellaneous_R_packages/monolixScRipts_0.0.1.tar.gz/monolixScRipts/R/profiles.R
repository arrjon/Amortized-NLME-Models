#' Initializing profiles
#' 
#' @param parameterBounds A list with names equal to the parameter IDs and vectors with c(lowerBound, upperBound) for each ID.
#' @param stepsize Either single value of float or integer, or vector with stepsizes for each parameter
#' @param parameters Either string "all", where it fetches the parameter IDs from the currently loaded Monolix project or a character vector of selected parameters
#' @param globalOptimum Vector of optimized parameter values. Should have the same length and order as `getPopulationParameterInformation` (`lixoftConnectors` function)
#' @param linearization Whether to use linearization of the model for likelihood computation (see Monolix documentation)
#' @export
profiles <- function(
    parameterBounds,
    globalOptimum = NULL,
    stepsize = 0.5,
    parameters = "all",
    linearization = TRUE,
    profileResult = NULL,
    saveDir = "./"
) {
    poppars <- lixoftConnectors::getPopulationParameterInformation()
    # Use optimization result to initialize parameters for profiles
    if (!is.null(globalOptimum)) {
        poppars$initialValue <- globalOptimum
    }
    writeLines("Setting initial parameter values.")
    lixoftConnectors::setPopulationParameterInformation(poppars)
    
    # Select which parameters profiles should be computed on
    if (parameters == "all") {
        # Get parameter ids from open Monolix project
        parameterIds <- poppars$name
        selectedParBounds <- parameterBounds[parameterIds]
    } else if (parameters == "free") {
        parameterInd <- poppars$method %in% c("MLE", "MAP")
        parameterIds <- poppars$name[parameterInd]
        selectedParBounds <- parameterBounds[parameterIds]
        globalOptimum <- globalOptimum[parameterInd]
    } else {
        parameterIds <- parameters
        parameterInd <- poppars$name %in% parameters
        selectedParBounds <- parameterBounds[parameterIds]
        globalOptimum <- globalOptimum[parameterInd]
    }

    # Run profile for parameterIds
    for (i in seq_along(parameterIds)) {
        # Select parameter
        p <- parameterIds[i]
        writeLines(paste0("Walking along profile for ", p))
        # Get parameter starting value
        init <- globalOptimum[i]
        # Get parameter bounds (where to stop profiles)
        bounds <- selectedParBounds[[p]]
        # print(lb, ub)
        profileResult <- runProfileForParameter(
            p,
            init,
            bounds,
            poppars,
            stepsize,
            linearization,
            profileResult
        )
        # Save for each parameter
        saveProfile(saveDir, profileResult)
    }
    return(profileResult)
}

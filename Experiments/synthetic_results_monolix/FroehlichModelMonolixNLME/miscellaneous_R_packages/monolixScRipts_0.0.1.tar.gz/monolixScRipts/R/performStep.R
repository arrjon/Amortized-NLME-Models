#' Perform one step along the profile
#' 
#' @export
performStep <- function(
    parameter,
    value,
    direction,
    stepsize,
    bounds,
    popparsInfo,
    ratio
) {
    writeLines(paste0("Current value (lb, ub): ", value, "(", bounds[1], ", ", bounds[2], ")"))
    # finished <- checkLikelihoodRatioThreshold(ratio)
    # Add stepsize to current parameter value
    newValue <- value + stepsize * direction
    # Check if the new parameter value would hit the bounds
    finished <- checkProfileBounds(newValue, bounds, direction)
    # Check if profile in the one direction is done
    if (finished == 1) {
        return(
            list(
                finishProfile = finished,
                parameterValue = value
            )
        )
    }
    # Set new parameter value in Monolix
    popparsInfo[popparsInfo$name == parameter, "initialValue"] <- newValue
    lixoftConnectors::setPopulationParameterInformation(popparsInfo)
    return(
        list(
            finishProfile = finished,
            parameterValue = newValue
        )
    )
}
#' Concatenate parameter estimation results
#' @export
concatResults <- function(lsEstimates, initPars, run, scenario) {
    # Create new list to sequentially fill with estimated parameters
    newList <- list()
    # Check which tasks were run
    # Depending on the set scenario `lsEstimates` contains different items
    if ("allPopPars" %in% attributes(lsEstimates)$names){
        # Save already estimated parameters
        allPopPars <- lsEstimates$allPopPars
        # Get estimated parameters
        newPoppars <- lixoftConnectors::getEstimatedPopulationParameters()
        # Check if parameter estimation was successfull
        if (length(newPoppars) != 0){
            # Add new estimates to old ones
            allPopPars <- cbind(allPopPars, newPoppars)
            cols <- colnames(allPopPars)
            cols[length(cols)] <- paste0("run_", run)
            colnames(allPopPars) <- cols
        } else {
            writeLines(paste0("SAEM failed for run", run))
        }
        newList$allPopPars <- allPopPars
        # Concat monolix convergence indicator values
        allIndicators <- lsEstimates$convergenceIndicator
        saemSummary <- lixoftConnectors::getSAEMiterations()
        if (length(saemSummary) != 0){
            indicator <- saemSummary$estimates$convergenceIndicator
            indicator <- indicator[length(indicator)]
            iterationNumbers <- saemSummary$iterationNumbers
            newIndicators <- list(
                run = run,
                convergenceIndicator = indicator,
                exploratoryNumber = iterationNumbers[1],
                smoothingNumber = iterationNumbers[2]
                )
            newIndicators <- rbind(
                allIndicators, as.data.frame(newIndicators)
            )
        }
        newList$convergenceIndicator <- newIndicators
    } else {
        allPopPars <- NULL
        lsIndicator <- NULL
    }
    # Concat best individual parameters
    if ("allIndPars" %in% attributes(lsEstimates)$names) {
        allIndPars <- lsEstimates$allIndPars
        # Check if EBE task and conditional mode estimations has been run (the `lsEstimates` should contain simulated parameters from the conditional distribution sampling task)
        if ("simPars" %in% attributes(lsEstimates)) {
            newIndPars <- lixoftConnectors::getEstimatedIndividualParameters()$conditionalMode
        # Otherwise use best individual parameters from SAEM
        } else {
            newIndPars <- lixoftConnectors::getEstimatedIndividualParameters()$saem
        }
        if (length(newIndPars) != 0){
            newIndPars$run <- run
            allIndPars <- rbind(allIndPars, newIndPars)
        }
        newList$allIndPars <- allIndPars
    } else {allIndPars <- NULL}
    # Concat all simulated individual parameters
    if ("simPars" %in% attributes(lsEstimates)$names){
        simPars <- lsEstimates$simPars
        newSimPars <- lixoftConnectors::getSimulatedIndividualParameters()
        if (length(newSimPars) != 0){
            newSimPars$run <- run
            simPars <- rbind(simPars, newSimPars)
        }
        newList$simPars <- simPars
    } else {simPars <- NULL}
    # Concat estimated standard errors
    if ("tabse" %in% attributes(lsEstimates)$names){
        tabse <- lsEstimates$tabse
        standardErrors <- lixoftConnectors::getEstimatedStandardErrors()
        # The standard errors task can either be run using a linearized model or with importance sampling
        if (scenario$linearization == T){
            if (length(standardErrors) != 0){
                rses <- standardErrors$linearization$rse
                names(rses) <- standardErrors$linearization$parameter
                tabse <- cbind(tabse, rses)
                tabse <- data.frame(tabse)
                cols <- colnames(tabse)
                cols[length(cols)] <- paste0("run_", run)
                colnames(tabse) <- cols
            }
        } else {
            if (length(standardErrors) != 0){
                rses <- standardErrors$stochasticApproximation$se
                names(rses) <- standardErrors$stochasticApproximation$parameter
                tabse <- cbind(tabse, rses)
                tabse <- data.frame(tabse)
                cols <- colnames(tabse)
                cols[length(cols)] <- paste0("se_run_", run)
                colnames(tabse) <- cols
            }
        }
        newList$tabse <- tabse
    } else {tabse <- NULL}
    # Concat estimated likelihood
    if ("ll" %in% attributes(lsEstimates)$names){
        ll <- lsEstimates$ll
        newLl <- lixoftConnectors::getEstimatedLogLikelihood()
        # The likelihood estimation task can also be run with a linearized model or via importance sampling
        if (scenario$linearization == T) {
            if (length(newLl) != 0) {
                newLl <- newLl$linearization
                newLl <- append(newLl, list(run = run))
                names(newLl)[length(newLl)] <- "run"
                ll <- rbind(ll, newLl)
                rownames(ll) <- seq_len(nrow(ll))
            }
        } else {
            if (length(newLl) != 0) {
                newLl <- newLl$importanceSampling
                newLl <- append(newLl, list(run = run))
                names(newLl)[length(newLl)] <- "run"
                ll <- rbind(ll, newLl)
                rownames(ll) <- seq_len(nrow(ll))
            }
        }
        newList$ll <- ll
    } else {
        ll <- NULL
    }

    # Concat intial parameter values
    if (length(initPars) != 0){
        newpopparams <- initPars
        initPars <- initPars[c("name", "initialValue")]
        colnames(initPars) <- c("id", paste0("run_", run))
        initPars <- lapply(
            1:nrow(newpopparams), function(x){
                return(newpopparams$initialValue[x])
            }
        )
        names(initPars) <- newpopparams$name
        allInitPars <- cbind(lsEstimates$initPars, initPars)
        colnames(allInitPars)[ncol(allInitPars)] <- paste0("run_", run)
        newList$initPars <- allInitPars
    }
    return(newList)
}
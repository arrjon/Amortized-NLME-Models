#' Save estimated parameter results
#' @export
saveResults <- function(saveDir, lsEstimates, times=NULL){
    # Write everything to .csv files
    # Write result of each task to a separate file
    if ("allPopPars" %in% attributes(lsEstimates)$names){
        # Save population parameters
        allPopPars <- lsEstimates$allPopPars
        utils::write.csv(
            allPopPars, paste0(saveDir, "population_parameters.csv")
        )
        # Save convergence indicators
        allIndicators <- lsEstimates$convergenceIndicator
        utils::write.csv(
            allIndicators, paste0(saveDir, "convergence_indicators.csv")
        )
    }
    if ("allIndPars" %in% attributes(lsEstimates)$names){
        # Save best individual parameters
        allIndPars <- lsEstimates$allIndPars
        utils::write.csv(
            allIndPars, 
            paste0(
                saveDir, 
                "individual_parameters.csv"
            )
        )
        }
    if ("simPars" %in% attributes(lsEstimates)$names){
        # Save all sampled parameters
        simPars <- lsEstimates$simPars
        utils::write.csv(
            simPars,
            paste0(
                saveDir,
                "simulated_parameters.csv"
            )
        )
    }
    if ("tabse" %in% attributes(lsEstimates)$names){
        # Save standard errors
        tabse <- lsEstimates$tabse
        utils::write.csv(tabse, paste0(saveDir, "standard_errors.csv"))
    }
    if ("ll" %in% attributes(lsEstimates)$names){
        # Save likelihood estimates
        ll <- lsEstimates$ll
        utils::write.csv(
            ll, 
            paste0(
                saveDir, 
                "log_likelihood.csv"
            )
        )
    }
    if ("initPars" %in% attributes(lsEstimates)$names){
        # Save initial parameter values
        initPars <- lsEstimates$initPars
        utils::write.csv(
            initPars, 
            paste0(
                saveDir, 
                "initial_parameters.csv"
            )
        )
    }
    if (!is.null(times)){
        # Save runtimes
        utils::write.csv(
            times,
            paste0(saveDir, "runtimes.csv")
        )
    }
    writeLines("Results have been saved.")
}
#' Running profile for one parameter
#' @export
runProfileForParameter <- function(
    parameterId,
    init,
    bounds,
    popparsInfo,
    stepsize = 0.5,
    linearization = TRUE,
    profileResult = NULL
) {
    # Set estimation method to "FIXED" for the one parameter
    popparsInfo <- fixParameter(parameterId, popparsInfo)
    # if (grepl("pop", parameterId)) {
    #     subId <- substring(parameterId, 1, stri_length(parameterId) - 4)
    #     omegaId <- paste0("omega_", subId)
    #     fixParameter(omegaId, popparsInfo)
    # }

    # Start profile
    round <- 0 # Indicator if profiles are done
    currentParameterValue <- init # Initial parameter value
    iter <- 1 # Iteration of loop
    while (round < 3) {
        # Run parameter estimation
        writeLines("SAEM...")
        lixoftConnectors::runPopulationParameterEstimation()
        # Run likelihood estimation
        writeLines("Likelihood...")
        lixoftConnectors::runLogLikelihoodEstimation(linearization)
        # Get estimated likelihood
        likelihoodResult <- lixoftConnectors::getEstimatedLogLikelihood()
        if (linearization == TRUE) {
            likelihood <- likelihoodResult$linearization['OFV']
            standardError <- likelihoodResult$linearization['standardError']
        } else {
            likelihood <- likelihoodResult$importanceSampling['OFV']
            standardError <- likelihoodResult$importanceSampling['standardError']
        }
        if (iter == 1) {
            optimalLikelihood <- likelihood / 2
            ratio <- 1
        } else {
            ratio <- exp(optimalLikelihood - likelihood / 2)
        }
        finishProfile <- checkLikelihoodRatioThreshold(ratio)
        # If the profile is finished in one direction, `finishProfile` is equal
        # to 1, otherwise it's 0
        round <- round + finishProfile
        # Create named vector with result
        result <- c()
        result['id'] <- parameterId
        result['value'] <- currentParameterValue
        result['log-likelihood'] <- likelihood
        result['standard_error'] <- standardError
        result['ratio'] <- ratio
        # Concatenate result for one value to the profile results
        profileResult <- rbind(profileResult, result)

        # Set direction depending on whether one direction is finished
        if (round == 0) {
            direction <- 1
        } else if (round == 1) {
            writeLines("Switching direction...")
            direction <- -1
            # After switching direction set the parameter value to the optimum
            currentParameterValue <- init
            round <- 2
        }

        # Perform one step
        step <- performStep(
            parameterId,
            currentParameterValue,
            direction,
            stepsize,
            bounds,
            popparsInfo,
            ratio
        )
        # If my next step would be outside of the specified bounds, we finish
        # the profile in that direction
        round <- round + step$finishProfile
        currentParameterValue <- step$parameterValue

        # Increment loop indicator by 1
        iter <- iter + 1
    }

    profileResult <- as.data.frame(profileResult)
    profileResult <- apply(profileResult, 2, as.character)
    # Unfix parameter
    popparsInfo[popparsInfo$name == parameterId, "method"] <- "MLE"
    # if (grepl("pop", parameterId)) {
    #     popparsInfo[popparsInfo$name == omegaId, "method"] <- "MLE"
    # }
    lixoftConnectors::setPopulationParameterInformation(popparsInfo)

    return(profileResult)
}

#' Depending on the specified scenario create a result object
#' @export
createEmptyResults <- function(scenario) {
    lsEstimatesEmpty <- list()
    if (scenario$tasks['populationParameterEstimation'] == T){
        lsEstimatesEmpty['allPopPars'] <- list(NULL)
        # Best individual parameters are always estimated (even with only SAEM)
        lsEstimatesEmpty['allIndPars'] <- list(NULL)
        # Save the last convergence indicator value from Monolix
        lsEstimatesEmpty['conergenceIndicator'] <- list(NULL)
    }
    if (scenario$tasks['conditionalDistributionSampling'] == T){
        lsEstimatesEmpty['simPars'] <- list(NULL)
    }
    if (scenario$tasks['standardErrorEstimation'] == T){
        lsEstimatesEmpty['tabse'] <- list(NULL)
    }
    if (scenario$tasks['logLikelihoodEstimation'] == T){
        lsEstimatesEmpty['ll'] <- list(NULL)
    }
    lsEstimatesEmpty['initPars'] <- list(NULL)
    return(lsEstimatesEmpty)
}
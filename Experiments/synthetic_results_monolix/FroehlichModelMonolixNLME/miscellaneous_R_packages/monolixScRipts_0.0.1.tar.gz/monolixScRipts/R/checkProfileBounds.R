#' Check whether the set bounds of the profile have been hit
#' 
#' @export
checkProfileBounds <- function(value, bounds, direction) {
    if (direction == 1) {
        finished <- value >= bounds[2]
        finished <- as.numeric(finished)
    } else if (direction == -1) {
        finished <- value <= bounds[1]
        finished <- as.numeric(finished)
    }
    return(finished)
}

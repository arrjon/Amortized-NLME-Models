#' Run the scenario
#' @export
runMyScenario <- function(scenario, times = NULL, currRun = NULL){
    # Run the tasks one at a time to get output of what is happening
    if (scenario$tasks['populationParameterEstimation'] == T){
        print("Population parameter estimation running...")
        saemStart <- as.numeric(Sys.time())
        lixoftConnectors::runPopulationParameterEstimation()
        saemStop <- as.numeric(Sys.time())
        print("Done!")
    } else{
        saemStart <- NaN
        saemStop <- NaN
    }
    if (scenario$tasks['conditionalDistributionSampling'] == T){
        print("Conditional distribution sampling running...")
        condStart <- as.numeric(Sys.time())
        lixoftConnectors::runConditionalDistributionSampling()
        condStop <- as.numeric(Sys.time())
        print("Done!")
    } else{
        condStart <- NaN
        condStop <- NaN
    }
    if (scenario$tasks['conditionalModeEstimation'] == T){
        print("Conditional mode estimation running...")
        modeStart <- as.numeric(Sys.time())
        lixoftConnectors::runConditionalModeEstimation()
        modeStop <- as.numeric(Sys.time())
        print("Done!")
    } else{
        modeStart <- NaN
        modeStop <- NaN
        }
    if (scenario$tasks['standardErrorEstimation'] == T){
        print("Standard error estimation running...")
        seStart <- as.numeric(Sys.time())
        lixoftConnectors::runStandardErrorEstimation(lixoftConnectors::getScenario()$linearization)
        seStop <- as.numeric(Sys.time())
        print("Done!")
    } else {
        seStart <- NaN
        seStop <- NaN
        }
    if (scenario$tasks['logLikelihoodEstimation'] == T){
        print("Log-likelihood estimation running...")
        llStart <- as.numeric(Sys.time())
        lixoftConnectors::runLogLikelihoodEstimation(lixoftConnectors::getScenario()$linearization)
        llStop <- as.numeric(Sys.time())
        print("Done!")
    }
    else {
        llStart <- NaN
        llStop <- NaN
    }
    # Save runtimes
    if (is.list(times)){
        newTimes <- list(
            saem = saemStop - saemStart,
            cond = condStop - condStart,
            mode = modeStop - modeStart,
            se = seStop - seStart,
            ll = llStop - llStart,
            run = currRun
        )
        newTimes <- as.data.frame(newTimes)
        times <- rbind(times, newTimes)
        rownames(times) <- seq_len(nrow(times))
        # times <- drop_na(times)
    } else if ((!is.null(times)) & !is.list(times)) {
       stop("`times` must be a list.")
    }
    print("Scenario is done!")
    # Only needs to return runtimes, because other functions will load the results
    return(times)
}

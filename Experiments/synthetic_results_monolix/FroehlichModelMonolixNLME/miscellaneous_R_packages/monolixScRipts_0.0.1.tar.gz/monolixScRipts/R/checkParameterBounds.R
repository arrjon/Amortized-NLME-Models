#' Load parameter bounds that are specified in a file
#' @param parBoundsPath Path of parameter initialization file
#' @export
checkParameterBounds <- function(parBoundsPath){
    # parBoundsPath <- paste0(projectInitDir, "parameter_bounds_", model, ".csv")
    if (file.exists(parBoundsPath)) {
        parBounds <- readParameterBounds(parBoundsPath)
    } else {
        parBounds <- NULL
    }
    return(parBounds)
}
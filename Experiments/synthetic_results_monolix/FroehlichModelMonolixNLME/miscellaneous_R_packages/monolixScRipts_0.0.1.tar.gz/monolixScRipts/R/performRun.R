# Start one optimization run
performRun <- function (
    nRuns, # Integer
    currRun, # Integer
    freePars, # As defined in self-specified parameter data frame
    popparams, # As given by lixoftConnectors::getPopulationParameterInformation
    scenario, # As given by lixoftConnectors::getScenario
    lsEstimates, # As created by createEmptyResults
    times = NULL,
    parBounds = NULL,
    sampleInit = TRUE
) {
    # Give user feedback
    writeLines(
        paste(lubridate::now(), ": Run", currRun, "/", nRuns, "hast started.")
    )

    # Sample initial parameter values
    freeParNames <- freePars$name
    bool <- popparams$name %in% freeParNames
    if (sampleInit == TRUE) {
        popini <- sampleInitialParameters(freePars, bounds = parBounds)
    } else {
        # noFixedPars <- popparams$method != "FIXED"
        popini <- popparams$initialValue[bool]
    }

    # Write initial parameter estimates
    newpopparams <- popparams
    # Only set the new parameters, where they should be estimated
    newpopparams$initialValue[bool] <- popini
    lixoftConnectors::setPopulationParameterInformation(newpopparams)

    # Create a unique id for the run
    runid <- lubridate::seconds(lubridate::now())
    runid <- gsub("[.]", "_", runid)
    runid <- gsub("S", "", runid)
    # Run the scenario
    times <- runMyScenario(scenario, times, runid)
    # Append estimates of the run to all estimates
    lsEstimates <- concatResults(lsEstimates, newpopparams, runid, scenario)

    # Give user status feedback
    writeLines(
        paste0("FINISHED: Run ", currRun, "/", nRuns, " has finished! Only ", nRuns-currRun, " to go.")
    )
    # Return new estimates and runtimes
    return(list(lsEstimates = lsEstimates, times = times))
}

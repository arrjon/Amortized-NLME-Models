#' Fix one parameter
#' @param populationParameterInfo Should be the population parameter info data frame that is provided by lixoftConnectors::getPopulationParameterInformation()
#' @export
fixParameter <- function(parameter, populationParameterInfo) {
    populationParameterInfo[populationParameterInfo$name == parameter, "method"] <- "FIXED"
    lixoftConnectors::setPopulationParameterInformation(populationParameterInfo)
    return(populationParameterInfo)
}

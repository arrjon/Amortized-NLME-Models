#' Read parameter bounds for initial parameter values that are specified in a .csv file
#' @param parBoundsPath Path to the parameter bounds csv file
#' @return Returns parameter bounds.


#' @export
readParameterBounds <- function(parBoundsPath){
    parBounds <- utils::read.csv(parBoundsPath)
    return(parBounds)
}